function siblings = get_siblings( cp, n )

siblings = find(cp==n);

return;