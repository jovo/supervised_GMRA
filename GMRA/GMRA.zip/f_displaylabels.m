function y = f_displaylabels( GWT, n, Data )

y = mean(GWT.Labels(GWT.PointsInNet{n}));

return;